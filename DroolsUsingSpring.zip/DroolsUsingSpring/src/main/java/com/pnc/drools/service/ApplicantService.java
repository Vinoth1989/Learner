package com.pnc.drools.service;

import java.io.IOException;

import org.kie.api.runtime.KieSession;

import com.pnc.drools.config.DroolsBeanFactory;
import com.pnc.drools.model.Applicant;
import com.pnc.drools.model.SuggestedRole;

public class ApplicantService {

    KieSession kieSession=new DroolsBeanFactory().getKieSession();

    public SuggestedRole suggestARoleForApplicant(Applicant applicant,SuggestedRole suggestedRole) throws IOException {
        kieSession.insert(applicant);
        kieSession.setGlobal("suggestedRole",suggestedRole);
        kieSession.fireAllRules();
        System.out.println(suggestedRole.getRole());
        return  suggestedRole;

    }
}
