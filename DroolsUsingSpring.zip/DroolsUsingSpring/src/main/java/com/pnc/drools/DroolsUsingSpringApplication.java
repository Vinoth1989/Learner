package com.pnc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DroolsUsingSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(DroolsUsingSpringApplication.class, args);
	}

}
